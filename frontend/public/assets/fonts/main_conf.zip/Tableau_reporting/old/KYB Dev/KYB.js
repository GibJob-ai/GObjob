//  initialize the viz variable
var viz;


window.onload= function() {
// when the webpage has loaded, load the viz
      var vizDiv = document.getElementById("myViz");
      var vizURL = "https://tableaussi-prod.cibcwm.com/t/RBB-BusControl/views/BCRMRecapDashboard-FY19/Transit?:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no";
      var options = {
          width: "100%",
          height: "1800px",
          hideTabs: true,
      };

      viz = new tableau.Viz(vizDiv, vizURL, options);

        // add functions to run when the user select marks or switches tabs
        //viz.addEventListener("marksselection", function(){
           // alert("Thu user selected marks");
        //});
        //viz.addeventListener("tabswitch", function(event){
        //    document.getElementById("sheetName").innerHTML = event.getNewSheetName();
        //});

};

//function Swap_Core_Fraud(SwapName){
    //if (SwapName == "Fraud"){
       // window.location.replace ("https://teams.cibc.com/sites/gormr/ori/ORI_Fraud.html");
    //}
//}

// just load another dashboard
function DashLoad(DashName, link){
    var vizDiv = document.getElementById("myViz");
    viz.dispose();
    var DashURL = "";

    var options = {
      width: "100%",
      height: "1800px",
      hideTabs: true,
    };
    var vizURL;
    
    //switch to change the tableau settings per page
    switch (DashName) {
      case "OICC":
        DashURL = "https://tableaussi-prod.cibcwm.com/t/RBB-BusControl/views/OICCFY19/OICCReporting?:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no";
        break;
      case "Home":
        DashURL = "https://tableaussi-prod.cibcwm.com/t/RBB-BusControl/views/BCRMRecapDashboard-FY19/Transit?:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no";

        break;
      case "Fates":
        DashURL = "https://tableaussi-prod.cibcwm.com/t/RBB-BusControl/views/FatesFY19/FatesReporting?:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no";
       break;
      
	case "SMNew":
        DashURL = "https://tableaussi-prod.cibcwm.com/t/RBB-BusControl/views/Sales_Monitoring_KYB/BCSalesMonitoringReviewOutcomes?iframeSizedToWindow=true&:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no";
	break;

      case "AML":
        DashURL = "https://tableaussi-prod.cibcwm.com/t/RBB-BusControl/views/AML_0/Dashboard1?:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no";

        break;
      case "Cash":
        DashURL = "https://tableaussi-prod.cibcwm.com/t/RBB-BusControl/views/FY19CashBranch/BranchCashReporting?:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no";

        break;
      case "OpLoss":
          DashURL = "https://tableaussi-prod.cibcwm.com/t/RBB-BusControl/views/OpLossMonitoring_201901_Revamped/OperationalLoss?:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no";

        break;
		case "MFDA":
          DashURL = "https://tableaussi-prod.cibcwm.com/t/RBB-BusControl/views/MFDAFY19/MFDADashboard?:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no";
		
		var options = {
          width: "100%",
          height: "2200px",
          hideTabs: true,
        };
        break;
		case "IIROC":
          DashURL = "https://tableaussi-prod.cibcwm.com/t/RBB-BusControl/views/IIROCFY19/IIROCDashboard?:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no";
		
		var options = {
          width: "100%",
          height: "2200px",
          hideTabs: true,
        };
        break;
      case "SC":
        DashURL = "https://tableaussi-prod.cibcwm.com/t/RBB-BusControl/views/ServiceCommitmentFY19/ServiceCommitmentDashboard?:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no";

        var options = {
          width: "100%",
          height: "2200px",
          hideTabs: true,
        };
        break;
      case "LDD":
        DashURL = "https://tableaussi-prod.cibcwm.com/t/RBB-BusControl/views/LDDDashboard/LDD-Geography?:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no";

        break;
      case "BCSM1":
        DashURL = "https://tableaussi-prod.cibcwm.com/t/RBB-BusControl/views/BankingCentres-ConductRiskSalesMonitoringOutcomes/BCSalesMonitoring-ReviewOutcomes?:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no";

        break;
      case "BCSM2":
        DashURL = "https://tableaussi-prod.cibcwm.com/t/RBB-BusControl/views/BankingCentres-ConductRiskSalesMonitoringOutcomes/BCSalesMonitoring-FinalEmployeeActions?%3Aembed=y&%3AshowAppBanner=false&%3Adisplay_count=no&%3AshowVizHome=no";

        break;
      case "DTS2":
        DashURL = "https://tableaussi-prod.cibcwm.com/t/RBB-BusControl/views/DutyTestingSummary/RDView?:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no";

        break;
      case "DTS1":
        DashURL = "https://tableaussi-prod.cibcwm.com/t/RBB-BusControl/views/DutyTestingSummary/RiskView?:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no";

        break;
      case "DTS3":
        DashURL = "https://tableaussi-prod.cibcwm.com/t/RBB-BusControl/views/DutyTestingSummary/DutyAdherenceIndicatorDB?:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no";

        break;
      case "CR":
        DashURL = "https://tableaussi-prod.cibcwm.com/t/RBB-BusControl/views/DutyTestingCriteriaResults/CriteriaResults?:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no";

        break;
      case "CTI":
        DashURL = "https://tableaussi-prod.cibcwm.com/t/RBB-BusControl/views/CentralizedTestingInsights/CTInsights?:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no";

        break;

	  case "SA":
        DashURL = "https://teams.cibc.com/sites/ibcs/FRS/Know%20Your%20Branch%20KYB%20Connaitre%20son%20centre%20bancaire/Tools_Reports/Suspense%20accounts";

        break;
	  case "Form":
        DashURL = "http://10.1.48.126:5000/";

        break;


      case "UGBCRM":
        DashURL = "https://teams.cibc.com/sites/gtrm/Partner%20Zone/Tableau%20Reporting/KYB/BCRM%20User%20Guide%202019%20(final).pdf";

        var options = {
          width: "100%",
          height: "1000px",
          hideTabs: true,
        };
        break;
	  case "UGERPM":
        DashURL = "https://teams.cibc.com/sites/gtrm/Partner%20Zone/Tableau%20Reporting/KYB/ERPM%20User%20Guide%202019%20(final).pdf";

        var options = {
          width: "100%",
          height: "1000px",
          hideTabs: true,
        };
        break;
      case "UGMRCB":
        DashURL = "https://teams.cibc.com/sites/gtrm/Partner%20Zone/Tableau%20Reporting/KYB/MRCB%20Guide%20de%20l'utilisateur%202019%20(final).pdf";

        var options = {
          width: "100%",
          height: "1000px",
          hideTabs: true,
        };
        break;
	  case "UGMRRE":
        DashURL = "https://teams.cibc.com/sites/gtrm/Partner%20Zone/Tableau%20Reporting/KYB/MRRE%20Guide%20de%20l'utilisateur%202019%20(final).pdf";

        var options = {
          width: "100%",
          height: "1000px",
          hideTabs: true,
        };
        break;
      case "KYB":
        DashURL = "https://teams.cibc.com/sites/gtrm/Partner%20Zone/Tableau%20Reporting/KYB/KYB%20Dashboard%20Quick%20Start%20Guide.pdf";

        var options = {
          width: "100%",
          height: "1000px",
          hideTabs: true,
        };
        break;
    }

    if(DashURL != ""){
      vizURL = DashURL;
      viz = new tableau.Viz(vizDiv, vizURL, options);
    }
    setActiveLink(link);
}

//Get active sheet

function setActiveLink(setActive){
    var links = document.querySelectorAll("#menuLinks a");
    Array.prototype.map.call(links, function(e) {
        e.className = "";
        if (e.id == setActive)
            e.className = "active";
	else e.className = "inactive";
    })
}


// switch the viz to the sheet specified
function switchView(sheetName){
    var workbook = viz.getWorkbook();
    workbook.activateSheetAsync(sheetName);
}

// filter the specified dimension to the specified value(s),  sheet.applyFilterAsync works for worksheet only
function show(filterName, values){
    var sheet = viz.getWorkbook().getActiveSheet();
    //the code below checks if it is worksheet else its a dashboard
    if(sheet.getSheetType() === tableau.SheetType.WORKSHEET){
        sheet.applyFilterAsync(filterName, values, tableau.FilterUpdateType.REPLACE);
    } 
    else{ //we know sheet.getSheetType() === tableau.SheetType.DASHBOARD    this will apply the filter to all of the worksheets in the dashboard
        var worksheetArray = sheet.getWorksheets();
        for(var i=0; i < worksheetArray.length; i++){
            worksheetArray[i].applyFilterAsync(filterName, values, tableau.FilterUpdateType.REPLACE);
        }
    }
}

// switch the viz and then apply filter.   all this does is to first load the viz and then apply the filter
function switchView_ApplyFilter(sheetName, filterName, values){
    var workbook = viz.getWorkbook();
    workbook.activateSheetAsync(sheetName).then(function(){
        var sheet = workbook.getActiveSheet();
        //sheet.applyFilterAsync(filterName, values, tableau.FilterUpdateType.REPLACE);
        if(sheet.getSheetType() === tableau.SheetType.WORKSHEET){
            sheet.applyFilterAsync(filterName, values, tableau.FilterUpdateType.REPLACE);
        } 
        else{ //we know sheet.getSheetType() === tableau.SheetType.DASHBOARD    this will apply the filter to all of the worksheets in the dashboard
            var worksheetArray = sheet.getWorksheets();
            for(var i=0; i < worksheetArray.length; i++){
                worksheetArray[i].applyFilterAsync(filterName, values, tableau.FilterUpdateType.REPLACE);
            }
        }
    })
}


// select the marks that have the specified value(s) for the specified dimension
function selectMarks(filterName, values){
    var sheet = viz.getWorkbook().getActiveSheet();
    sheet.applyMarksAsync(filterName, values, tableau.FilterUpdateType.REPLACE);
}


// Close the dropdown menu if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches(".dropbtn")) {

    var dropdowns = document.getElementsByClassName("dropdown-content");
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains("show")) {
        openDropdown.classList.remove("show");
      }
    }
  }
}

// content below is to resolve warning for missing "tableau" object
var tableau;
