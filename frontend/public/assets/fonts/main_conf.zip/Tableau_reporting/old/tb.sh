#!/bin/bash 

while [1];do
    sass test.scss test.css  
done
