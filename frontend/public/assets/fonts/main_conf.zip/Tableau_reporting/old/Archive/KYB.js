//  initialize the viz variable
var viz;


window.onload= function() {
// when the webpage has loaded, load the viz
        var vizDiv = document.getElementById('myViz');
        var vizURL = 'https://tableaussi-prod.cibcwm.com/t/RBB-BusControl/views/BCRMRecapDashboard-FY19/Transit?:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no';
        var options = {
            width: '100%',
            height: '1800px',
            hideTabs: true,
            //hideToolbar: false

            //  add a function to run when the viz is done initiatizing
            //onFirstInteractive: function(){
            //    document.getElementById('sheetName').innerHTML = viz.getWorkbook().getActiveSheet().getName();
            //}
        };

        viz = new tableau.Viz(vizDiv, vizURL, options);

        // add functions to run when the user select marks or switches tabs
        //viz.addEventListener('marksselection', function(){
           // alert('Thu user selected marks');
        //});
        //viz.addeventListener('tabswitch', function(event){
        //    document.getElementById('sheetName').innerHTML = event.getNewSheetName();
        //});
        
};

//function Swap_Core_Fraud(SwapName){
    //if (SwapName == 'Fraud'){
       // window.location.replace ("https://teams.cibc.com/sites/gormr/ori/ORI_Fraud.html");
    //}
//}

// just load another dashboard
function DashLoad(DashName, link){
    var vizDiv = document.getElementById('myViz');
    viz.dispose();
    var DashURL

    DashURL = ''

    if (DashName == 'OICC'){
        DashURL = 'https://tableaussi-prod.cibcwm.com/t/RBB-BusControl/views/OICCFY19/OICCReporting?:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no';
        
        var options = {
            width: '100%',
            height: '1800px',
            hideTabs: true,
        };
        }
    else if (DashName == 'Home'){
        DashURL = 'https://tableaussi-prod.cibcwm.com/t/RBB-BusControl/views/BCRMRecapDashboard-FY19/Transit?:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no';
        
        var options = {
            width: '100%',
            height: '1800px',
            hideTabs: true,
        };
        }
    else if (DashName == 'Fates'){
        DashURL = 'https://tableaussi-prod.cibcwm.com/t/RBB-BusControl/views/FatesFY19/FatesReporting?:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no';

        var options = {
            width: '100%',
            height: '1800px',
            hideTabs: true,
        };
        }

    else if (DashName == 'AML'){
        DashURL = 'https://tableaussi-prod.cibcwm.com/t/RBB-BusControl/views/AML_0/Dashboard1?:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no';

        var options = {
            width: '100%',
            height: '1800px',
            hideTabs: true,
        };
        }

    else if (DashName == 'Cash'){
        DashURL = 'https://tableaussi-prod.cibcwm.com/t/RBB-BusControl/views/FY19CashBranch/BranchCashReporting?:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no';

        var options = {
            width: '100%',
            height: '1800px',
            hideTabs: true,
        };
        }

    else if (DashName == 'OpLoss'){
        DashURL = 'https://tableaussi-prod.cibcwm.com/t/RBB-BusControl/views/OpLossMonitoring_201901_Revamped/OperationalLoss?:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no';

        var options = {
            width: '100%',
            height: '1800px',
            hideTabs: true,
        };
        }

    else if (DashName == 'SC'){
        DashURL = 'https://tableaussi-prod.cibcwm.com/t/RBB-BusControl/views/ServiceCommitmentFY19/ServiceCommitmentDashboard?:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no';

        var options = {
            width: '100%',
            height: '2200px',
            hideTabs: true,
        };
        }
		
	else if (DashName == 'IIROC'){
        DashURL = 'https://tableaussi-prod.cibcwm.com/t/RBB-BusControl/views/IIROCFY19/IIROCDashboard?:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no';

        var options = {
            width: '100%',
            height: '2200px',
            hideTabs: true,
        };
        }

    else if (DashName == 'LDD'){
        DashURL = 'https://tableaussi-prod.cibcwm.com/t/RBB-BusControl/views/LDDDashboard/LDD-Geography?:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no';

        var options = {
            width: '100%',
            height: '1800px',
            hideTabs: true,
        };
        }

    else if (DashName == 'BCSM1'){
        DashURL = 'https://tableaussi-prod.cibcwm.com/t/RBB-BusControl/views/BankingCentres-ConductRiskSalesMonitoringOutcomes/BCSalesMonitoring-ReviewOutcomes?:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no';

        var options = {
            width: '100%',
            height: '1800px',
            hideTabs: true,
        };
        }

    else if (DashName == 'BCSM2'){
        DashURL = 'https://tableaussi-prod.cibcwm.com/t/RBB-BusControl/views/BankingCentres-ConductRiskSalesMonitoringOutcomes/BCSalesMonitoring-FinalEmployeeActions?%3Aembed=y&%3AshowAppBanner=false&%3Adisplay_count=no&%3AshowVizHome=no';

        var options = {
            width: '100%',
            height: '1800px',
            hideTabs: true,
        };
        }

    else if (DashName == 'DTS1'){
        DashURL = 'https://tableaussi-prod.cibcwm.com/t/RBB-BusControl/views/DutyTestingSummary/RiskView?:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no';

        var options = {
            width: '100%',
            height: '1800px',
            hideTabs: true,
        };
        }

    else if (DashName == 'DTS2'){
        DashURL = 'https://tableaussi-prod.cibcwm.com/t/RBB-BusControl/views/DutyTestingSummary/RDView?:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no';

        var options = {
            width: '100%',
            height: '1800px',
            hideTabs: true,
        };
        }

    else if (DashName == 'DTS3'){
        DashURL = 'https://tableaussi-prod.cibcwm.com/t/RBB-BusControl/views/DutyTestingSummary/DutyAdherenceIndicatorDB?:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no';

        var options = {
            width: '100%',
            height: '1800px',
            hideTabs: true,
        };
        }

    else if (DashName == 'CR'){
        DashURL = 'https://tableaussi-prod.cibcwm.com/t/RBB-BusControl/views/DutyTestingCriteriaResults/CriteriaResults?:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no';

        var options = {
            width: '100%',
            height: '1800px',
            hideTabs: true,
        };
        }

    else if (DashName == 'CTI'){
        DashURL = 'https://tableaussi-prod.cibcwm.com/t/RBB-BusControl/views/CentralizedTestingInsights/CTInsights?:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no';

        var options = {
            width: '100%',
            height: '1800px',
            hideTabs: true,
        };
        }

    else if (DashName == 'UGBCRM'){
        DashURL = 'https://teams.cibc.com/sites/gtrm/Partner%20Zone/Tableau%20Reporting/KYB/BCRM%20User%20Guide%202019%20(final).pdf';

        var options = {
            width: '100%',
            height: '90%',
            hideTabs: true,
        };
        }

    else if (DashName == 'KYB'){
        DashURL = 'https://teams.cibc.com/sites/gtrm/Partner%20Zone/Tableau%20Reporting/KYB/KYB%20Dashboard%20Quick%20Start%20Guide.pdf';

        var options = {
            width: '100%',
            height: '90%',
            hideTabs: true,
        };
        }

    else {DashURL='';}
    
    if (DashURL != ''){
        var vizURL = DashURL

       // var options = {
       //     width: '100%',
       //     height: length_len,
       //     hideTabs: true,
       // };

        viz = new tableau.Viz(vizDiv, vizURL, options);}
setActiveLink(link)
}

//Get active sheet

function setActiveLink(setActive){
    var links = document.querySelectorAll("#menuLinks a");
    Array.prototype.map.call(links, function(e) {
        e.className = "";
        if (e.id == setActive)
            e.className = "active"
	else e.className = "inactive";
    })
}


// switch the viz to the sheet specified
function switchView(sheetName){
    var workbook = viz.getWorkbook();
    workbook.activateSheetAsync(sheetName);
}

// filter the specified dimension to the specified value(s),  sheet.applyFilterAsync works for worksheet only
function show(filterName, values){
    var sheet = viz.getWorkbook().getActiveSheet();
    //the code below checks if it is worksheet else its a dashboard
    if(sheet.getSheetType() === tableau.SheetType.WORKSHEET){
        sheet.applyFilterAsync(filterName, values, tableau.FilterUpdateType.REPLACE);
    } else{ //we know sheet.getSheetType() === tableau.SheetType.DASHBOARD    this will apply the filter to all of the worksheets in the dashboard
        var worksheetArray = sheet.getWorksheets();
        for(var i=0; i < worksheetArray.length; i++){
            worksheetArray[i].applyFilterAsync(filterName, values, tableau.FilterUpdateType.REPLACE);
        }
    }
}

// switch the viz and then apply filter.   all this does is to first load the viz and then apply the filter
function switchView_ApplyFilter(sheetName, filterName, values){
    var workbook = viz.getWorkbook();
    workbook.activateSheetAsync(sheetName).then(function(){
        var sheet = workbook.getActiveSheet();
        //sheet.applyFilterAsync(filterName, values, tableau.FilterUpdateType.REPLACE);
        if(sheet.getSheetType() === tableau.SheetType.WORKSHEET){
            sheet.applyFilterAsync(filterName, values, tableau.FilterUpdateType.REPLACE);
        } else{ //we know sheet.getSheetType() === tableau.SheetType.DASHBOARD    this will apply the filter to all of the worksheets in the dashboard
            var worksheetArray = sheet.getWorksheets();
            for(var i=0; i < worksheetArray.length; i++){
                worksheetArray[i].applyFilterAsync(filterName, values, tableau.FilterUpdateType.REPLACE);
            }
        }
    })
}


// select the marks that have the specified value(s) for the specified dimension
function selectMarks(filterName, values){
    var sheet = viz.getWorkbook().getActiveSheet();
    sheet.applyMarksAsync(filterName, values, tableau.FilterUpdateType.REPLACE)
}

function myFunction1() {
    document.getElementById("myDropdown1").classList.toggle("show");
}

function myFunction2() {
    document.getElementById("myDropdown2").classList.toggle("show");
}

function myFunction3() {
    document.getElementById("myDropdown3").classList.toggle("show");
}

// Close the dropdown menu if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {

    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}

// content below is to resolve warning for missing 'tableau' object
var tableau;