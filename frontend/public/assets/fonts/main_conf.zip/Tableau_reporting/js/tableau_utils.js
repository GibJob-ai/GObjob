export function DashLoad(DashName, firstLoad=false){
  const  topbarHeight = 50; // If you change this, remember to change it in the SCSS as well!
  const vizXY = ['100%', window.innerHeight-topbarHeight+'px'];
  const vizOptionsGlobal = {
    width: vizXY[0],
    height: vizXY[1],
    hideTabs: true,
  };
  let vizDiv = document.getElementById("myViz");
  
  let vizOptions = Object.assign({}, vizOptionsGlobal);
  vizOptions = Object.assign(vizOptions, getFilterValues());
  console.log('vizOptions');
  //console.log(vizOptions); 
  for(var pair of Object.entries(vizOptions)) {
    console.log(pair[0]+ ', '+ pair[1]);
  }
  
  let homeUrl = "https://tableaussi-prod.cibcwm.com/t/DelOps/views/BCRMRecapDashboard-FY19/Transit?:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no";

  if (firstLoad){
    vizOptions['Transit']='00001'; // Janky fix for a weird browser cookie issue where if we load without this option, it will be stuck on transit 1.
    // Instead, we explicitly load transit 1, and then remove the option to allow loading all transits.
    // If anyone knows how to fix this in the future, please do
    viz = new tableau.Viz(vizDiv, homeUrl, vizOptions);

    delete(vizOptions['Transit']);
  }

  viz.dispose();

  let DashURL = "";
    
    //switch to change the tableau settings per page
    switch (DashName) {
      case "OICC":
        DashURL = "https://tableaussi-prod.cibcwm.com/t/DelOps/views/OICCFY19/OICCReporting?:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no";
        break;
      case "Home":
        DashURL = homeUrl;
        break;
      case "Fates":
        DashURL = "https://tableaussi-prod.cibcwm.com/t/DelOps/views/FatesFY19/FatesReporting?:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no";
       break;
      
	case "SMNew":
        DashURL = "https://tableaussi-prod.cibcwm.com/t/DelOps/views/Sales_Monitoring_KYB/BCSalesMonitoringReviewOutcomes?iframeSizedToWindow=true&:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no";
	break;

      case "AML":
        DashURL = "https://tableaussi-prod.cibcwm.com/t/DelOps/views/AML_0/Dashboard1?:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no";

        break;
      case "Cash":
        DashURL = "https://tableaussi-prod.cibcwm.com/t/DelOps/views/FY19CashBranch/BranchCashReporting?:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no";

        break;
      case "OpLoss":
          DashURL = "https://tableaussi-prod.cibcwm.com/t/DelOps/views/OpLossMonitoring_201901_Revamped/OperationalLoss?:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no";

        break;
		case "MFDA":
          DashURL = "https://tableaussi-prod.cibcwm.com/t/DelOps/views/MFDAFY19/MFDADashboard?:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no";
		
		// var options = {
          // width: "100%",
          // height: "2200px",
          // hideTabs: true,
        // };
        break;
		case "IIROC":
          DashURL = "https://tableaussi-prod.cibcwm.com/t/DelOps/views/IIROCFY19/IIROCDashboard?:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no";
		
    // var options = {
          // width: "100%",
          // height: "2200px",
          // hideTabs: true,
        // };
        break;
      case "SC":
        DashURL = "https://tableaussi-prod.cibcwm.com/t/DelOps/views/ServiceCommitmentFY19/ServiceCommitmentDashboard?:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no";

        // var options = {
          // width: "100%",
          // height: "2200px",
          // hideTabs: true,
        // };
        break;		
	  case "CR_Summary":
        DashURL = "https://tableaussi-prod.cibcwm.com/t/DelOps/views/CBFE_SC_Simplified_Dashboard/CBFE_SC_Simplified?iframeSizedToWindow=true&:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no";

        // var options = {
          // width: "100%",
          // height: "2200px",
          // hideTabs: true,
        // };
        break;
	  case "CR_TXN":
        DashURL = "https://tableaussi-prod.cibcwm.com/t/DelOps/views/CBFE_SC_Transactions_Dashboard/CBFE_SC_Transactions_Dashboard?iframeSizedToWindow=true&:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no";

        // var options = {
          // width: "100%",
          // height: "2200px",
          // hideTabs: true,
        // };
        break;
      case "LDD":
        DashURL = "https://tableaussi-prod.cibcwm.com/t/DelOps/views/LDDDashboard/LDD-Geography?:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no";

        break;
      case "LDD_RQ":
        DashURL = "https://tableaussi-prod.cibcwm.com/t/DelOps/views/LendingDueDiligenceRandomQueueEscalations/LDDRQDashboard?iframeSizedToWindow=true&:embed=y&:display_count=no&:showAppBanner=false&:showVizHome=no";

        break;
      case "LDD_New":
        DashURL = "https://tableaussi-prod.cibcwm.com/t/DelOps/views/LDDDashboardKYBRevamp/LDDDashboard?iframeSizedToWindow=true&%3Aembed=y&%3AshowAppBanner=false&%3Adisplay_count=no&%3AshowVizHome=no#1";

        break;
	  case "BCSM1":
        DashURL = "https://tableaussi-prod.cibcwm.com/t/DelOps/views/BankingCentres-ConductRiskSalesMonitoringOutcomes/BCSalesMonitoring-ReviewOutcomes?:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no";

        break;
      case "BCSM2":
        DashURL = "https://tableaussi-prod.cibcwm.com/t/DelOps/views/BankingCentres-ConductRiskSalesMonitoringOutcomes/BCSalesMonitoring-FinalEmployeeActions?%3Aembed=y&%3AshowAppBanner=false&%3Adisplay_count=no&%3AshowVizHome=no";

        break;
      case "DTS2":
        DashURL = "https://tableaussi-prod.cibcwm.com/t/DelOps/views/DutyTestingSummary/RDView?:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no";

        break;
      case "DTS1":
        DashURL = "https://tableaussi-prod.cibcwm.com/t/DelOps/views/DutyTestingSummary/RiskView?:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no";

        break;
      case "DTS3":
        DashURL = "https://tableaussi-prod.cibcwm.com/t/DelOps/views/DutyTestingSummary/DutyAdherenceIndicatorDB?:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no";

        break;
      case "CR":
        DashURL = "https://tableaussi-prod.cibcwm.com/t/DelOps/views/DutyTestingCriteriaResults/CriteriaResults?:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no";

        break;
      case "CTI":
        DashURL = "https://tableaussi-prod.cibcwm.com/t/DelOps/views/CentralizedTestingInsights/CTInsights?:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no";

        break;

	case "SA":
        DashURL = "https://teams.cibc.com/sites/ibcs/FRS/Know%20Your%20Branch%20KYB%20Connaitre%20son%20centre%20bancaire/Reports/Suspense%20accounts";

        break;
	case "WhatsNew":
        DashURL = "https://teams.cibc.com/sites/ibcs/FRS/Know%20Your%20Branch%20KYB%20Connaitre%20son%20centre%20bancaire/What's%20New.pdf";

        break;
	case "TimelineSLA":
        DashURL = "https://teams.cibc.com/sites/gtrm/Partner%20Zone/Tableau%20Reporting/KYB/KYB%20Dashboard%20Expected%20Publication%20and%20Owners.pdf";

        break;
      case "UGBCRM":
        DashURL = "https://teams.cibc.com/sites/gtrm/Partner%20Zone/Tableau%20Reporting/KYB/BCRM%20User%20Guide%202019%20(final).pdf";

        // var options = {
          // width: "100%",
          // height: "1000px",
          // hideTabs: true,
        // };
        break;
	  case "UGERPM":
        DashURL = "https://teams.cibc.com/sites/gtrm/Partner%20Zone/Tableau%20Reporting/KYB/ERPM%20User%20Guide%202019%20(final).pdf";

        // var options = {
          // width: "100%",
          // height: "1000px",
          // hideTabs: true,
        // };
        break;
      case "UGMRCB":
        DashURL = "https://teams.cibc.com/sites/gtrm/Partner%20Zone/Tableau%20Reporting/KYB/MRCB%20Guide%20de%20l'utilisateur%202019%20(final).pdf";

        // var options = {
          // width: "100%",
          // height: "1000px",
          // hideTabs: true,
        // };
        break;
	  case "UGMRRE":
        DashURL = "https://teams.cibc.com/sites/gtrm/Partner%20Zone/Tableau%20Reporting/KYB/MRRE%20Guide%20de%20l'utilisateur%202019%20(final).pdf";

        // var options = {
          // width: "100%",
          // height: "1000px",
          // hideTabs: true,
        // };
        break;
      case "KYB":
        DashURL = "https://teams.cibc.com/sites/gtrm/Partner%20Zone/Tableau%20Reporting/KYB/KYB%20Dashboard%20Quick%20Start%20Guide.pdf";

        // var options = {
          // width: "100%",
          // height: "1000px",
          // hideTabs: true,
        // };
        break;
    }
    if(DashURL != ""){
      vizURL = DashURL;
      viz = new tableau.Viz(vizDiv, vizURL, vizOptions);
    }
}
