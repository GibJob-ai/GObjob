var active = false;
var sidebarWidth = "220px";
var lang=1;
var viz;
var tableau;
var vizXY;
var vizDiv;
var vizOptionsGlobal;
var hamburger;
var activeTitle;
var allFilters=['Transit', 'Community', 'Date'];


// UNUSED, TODO delete if still unused
function vizResize(newX=x, newY=y, rel=false) {
  if (rel){
    newX += x;
    newY += y;
  }
  newX=2000;
  viz.setFrameSize(newX, newY);
  //vizDiv.style.width = newX+'px';
  //vizDiv.style.height = newY+'px';
}

function toggleSidebar(){
  hamburger.classList.toggle("is-active");
  var sidebar = document.querySelector(".sidebar");
  var topbar= document.querySelector(".topbar");
  if (active) {
    sidebar.style.width = "0";
    // sidebar.style.display = "none";
    topbar.style.marginLeft = "0";
    vizDiv.style.marginLeft = "0";
  }
  else{
    // sidebar.style.display = "block";
    sidebar.style.width = sidebarWidth;
    topbar.style.marginLeft = sidebarWidth;
    vizDiv.style.marginLeft = sidebarWidth;
  }
  active = !active;
}

function enableAddFilterButton(){
  let addFilterButton = document.getElementById('addFilterButton');
  addFilterButton.disabled = false;
}

function addFilter(){
  let panel = document.getElementById('filter-panel');
  let list = document.getElementById('filter-list');
  let addFilter = document.getElementById('addFilter');
  let addFilterButton = document.getElementById('addFilter');
  let newFilterSelect = document.getElementById('newFilterSelect');

  let selectionName = newFilterSelect.options[newFilterSelect.selectedIndex].name;

  addFilterButton.disabled = true;

  let newFilter = document.createElement('div');
  newFilter.classList.add('filter');
  newFilter.name = selectionName;

  let newXButton = document.createElement('button');
  let newXIcon = document.createElement('i');
  newXButton.classList.add('roundButtonInvisible');
  newXIcon.classList.add('fas');
  newXIcon.classList.add('fa-times-circle');
  newXButton.appendChild(newXIcon);
  newXButton.onclick = function(){
    let select2 = document.getElementById('newFilterSelect');
    this.parentNode.parentNode.removeChild(this.parentNode);
    for (let i=0; i<select2.options.length; i++){
      if (select2.options[i].name==this.parentNode.name){
        select2.options[i].disabled = false;
      }
    }
  };

  newFilter.appendChild(newXButton);

  // Don't really need another label for the date filter because it has the start month & end month labels already
  if (selectionName != 'Date'){
    let newLabel = document.createElement('span');
    newLabel.innerHTML = selectionName;
    newFilter.appendChild(newLabel);
  }

  // newFilter.appendChild(newSelect);
  newFilter.appendChild(addFilterInput(selectionName));

  list.insertBefore(newFilter, list.lastChild);
  newFilterSelect.options[newFilterSelect.selectedIndex].disabled = true;
  newFilterSelect.selectedIndex = 0;
}

function getFilterValues(){
  let dict={};
  if (document.getElementById('Transit')!=undefined){
    let transit = document.getElementById('Transit').value;
    if (transit != '00000'){
      dict['Transit'] = transit;
    }
  }
  console.log('transit: ', dict['Transit']); 

  if (document.getElementById('Community')!=undefined){
    var community = document.getElementById('Community').value;
    if (community != '00000'){
      dict['Community'] = community;
    }
  }

  let defaultStart = '2018-11';
  let defaultEnd= '2020-11';

  if (document.getElementById('Date')!=undefined){
    var start = document.getElementById('Start Month').value;
    
    var end = document.getElementById('End Month').value;

    if (start){
      dict['Start_Month']=start;
    }
    if (end){
      dict['End_Month']=end;
    }
  }
  console.log('calling getFilterValues. dict:'); 
  console.log(dict); 
  return dict; 
}

function addFilterInput(i){
  if (i=='Transit' || i == 'Community'){
    // let container = document.createElement('div');
    let e = document.createElement('input');
    e.type = "text";
    e.id = i;
    e.value = '00000';
    setInputFilter(e, function(value) {
        return /^\d*$/.test(value);
    }, 5);
    return e;
  }
  else if (i == 'Date'){
    let container = document.createElement('div');
    container.classList.add('column-container')
    let labels = document.createElement('div');
    let months = document.createElement('div');
    
    let start = document.createElement('input');
    start.type = "month";
    start.id = 'Start Month';
    let end = document.createElement('input');
    end.type = "month";
    end.id = 'End Month';

    let labelTop = document.createElement('span');
    let labelBot = document.createElement('span');
    labelTop.innerHTML = 'Start Month';
    labelBot.innerHTML = 'End Month';
    
    labels.appendChild(labelTop);
    labels.appendChild(labelBot);

    months.appendChild(start);
    months.appendChild(end);

    months.id = i;

    container.appendChild(labels);
    container.appendChild(months);

    return container;
  }
}

function toggleFilters(){
  let panel = document.getElementById('filter-panel');
  panel.classList.toggle('open');
  setFilterButtonText();
}

function clearFilters(){
  let select = document.getElementById('newFilterSelect');
  for (let i=0; i<select.options.length; i++){
    select.options[i].disabled = false;
  }
  let filters = $('.filter:not(#addFilter)');
  filters.remove();

  refreshDashboard();
}

function refreshDashboard(){
  let activeLink = $('.active');
  if (activeLink.length > 1){
    alert('error, more than one link active?');
  }
  activeLink = activeLink[0];
  activeLink.click();
}

window.onload = function() {
  // Look for .hamburger
  toggleLang();
  vizDiv = document.getElementById("myViz");
  
  hamburger = document.querySelector(".hamburger");

  // On click
  hamburger.addEventListener("click", toggleSidebar);

  setTitle('link_Home');

  DashLoad('Home', firstLoad=true);
  
  let newFilterSelect = document.getElementById('newFilterSelect');
  allFilters.forEach(function (value, i) {
    let newOption = document.createElement('option');
    newOption.innerHTML = value;
    newOption.name = value;
    newFilterSelect.appendChild(newOption);
  });; 
    
  let listMain = document.getElementById("sidebar-list");
  //console.log(listMain);

  setupList(listMain);

  function setupList(list, depth=0){
    //console.log("depth"+depth);
    let listItems=getChild(list, "li");
    //console.log("listItems");
    //console.log(listItems);
    for (let i=0; i<listItems.length; i++){
      let curListItem = listItems[i];
      //console.log('curListItem:');
      //console.log(curListItem);
      curListItem.classList.add("d"+depth.toString());
      let childList = getChild(curListItem, "ul")[0];
      let siblingLink = getChild(curListItem, "a")[0];
      // if (siblingLink)
      siblingLink.classList.add("d"+depth.toString());
      if (childList){
        childList.classList.add("closed");
        childList.classList.add("d"+depth.toString());
        siblingLink.classList.add("closed");
        
        getChild(curListItem, "a")[0].addEventListener("click", function(){
          // TODO: recursively close lists
          //console.log("clicked dropdown");
          childList.classList.toggle("open");
          childList.classList.toggle("closed");
          siblingLink.classList.toggle("open");
          siblingLink.classList.toggle("closed");
        });
        //console.log('calling recurse from '+depth);
        setupList(childList, depth+1);
      }
      else{ // must be a link?
        //console.log("Adding ROOT LINK listener for siblingLink:");
        //console.log(siblingLink);
        siblingLink.addEventListener("click", function(){
          // use the ID of the link to swap pages!
          $('.active').addClass('inactive');
          $('.active').removeClass('active');

          siblingLink.classList.add("active");
          siblingLink.classList.remove("inactive");

          closeNonParents(siblingLink);

          setTitle(siblingLink.id);
          
          if (active){
            toggleSidebar();
          }
        });
      }
    }
  }
  
  // Clicking the title / logo on the topbar is equivalent to pressing the home button in the sidemenu
  document.getElementById('home-button-including-logo').addEventListener('click', function(){
    document.getElementById('link_Home').click();
  });
};

function closeNonParents(elem){
  let grp = $('ul.open');
  //console.log("TEMP");
  //console.log(elem);
  //console.log("startloop");
  for (let i=0; i<grp.length; i++){
    //console.log(jQuery.contains(grp[i], elem));
    if (jQuery.contains(grp[i], elem)){
      //console.log("found"); 
      //console.log(grp[i]);
    }
    else{
      //console.log("notfound"); 
      //console.log(grp[i]);
      let a = $(getSiblings(grp[i], "a"))[0];
      $(grp[i]).removeClass("open");
      $(grp[i]).addClass("closed");
      $(a).removeClass("open");
      $(a).addClass("closed");
    }
  }
}

// Takes an element, finds a child inside depending on childType, ie. "ul" or "a"
function getChild(elem, childType){
  let all = elem.childNodes;
  let list = [];
  for (let i=0; i<all.length; i++){
    if (all[i].tagName==childType.toUpperCase()){
      list.push(all[i]);
    }
  }
  return list;
}

function getSiblings(elem, type) {
	// Setup siblings array and get the first sibling
	let siblings = [];
	let sibling = elem.parentNode.firstChild;

	// Loop through each sibling and push to the array
  while (sibling) {

    if (sibling.nodeType === 1 && sibling !== elem) {
      if (type!==undefined){
        if (sibling.tagName == type.toUpperCase()){
          siblings.push(sibling);
        }
      }
      else{
        siblings.push(sibling);
      }
		}
		sibling = sibling.nextSibling;
	}
	return siblings;
};

var text = {
  "link_AML": ["AML", "LBA"],
  "link_Cash": ["Cash","Avoirs Liquides"],
  "drop_Client":["Client","Client"],
  "link_SC":["Service Commitment Entries","Compte d’Attente"],
  "link_CR_Summary":["Client Reimbursement - Summary","Remboursement Client – Sommaire"],
  "link_CR_TXN":["Client Reimbursement - Transactions","Remboursement Client - Transactions"],
  "link_Fates":["Fates","Avis de Sort"],
  "link_IIROC":["IIROC","OCRCVM"],
  "link_MFDA":["MFDA","ACCFM"],
  "link_OICC":["OICC","CCAI"],
  "link_OpLoss":["OpLoss","Pertes Opérationnelles"],
  "link_SM":["SM","SM"],
  "drop_Duties":["Duties","Tâches"],
  "link_DTS3":["Duty Testing Summary - Duty Adherence","Examens Des Tâches - Conformes"],
  "link_DTS1":["Duty Testing Summary - Risk View","Duty Testing Summary - Risk View"],
  "link_DTS2":["Duty Testing Summary - RD View","Examens Des Tâches -  Vue de Distribution Détail"],
  "link_CR":["Duty Testing Criteria Results","Examens Des Tâches-Résultats Critères"],
  "link_CTI":["Centralized Testing Insights","Évaluations Centralisées - Aperçu"],
  "drop_LDD":["LDD","LDD"],
  "link_LDD":["Lending Due Diligence","Contrôle Préalable Au Crédit"],
  "link_LDD_New":["Lending Due Diligence (New)","Contrôle Préalable Au Crédit (Nouveau)"],
  "link_LDD_RQ":["LDD Random Queue","Contrôle Préalable Au Crédit- File d'Attente"],
  "link_SA":["SA","SA"],
  "link_KYB":["KYB Start Guide","CVB Guide De Référence"],
  "drop_BCRM_UG":['BCRM User Guide','MRCRA - Guide De l’Utilisateur'],
  "link_UGBCRM":["English","English"],
  "link_UGMRCB":["French","French"],
  "link_ERPM_UG":['ERPM User Guide','MRRE - Guide De l’Utilisateur'],
  "link_UGERPM":["English","English"],
  "link_UGMRRE":["French","French"],
  "link_WhatsNew":["What's New","Quoi De Neuf"],
  "link_TimelineSLA":["Timeline SLA","Distribution Des Rapports"],
  "link_GetAccess":["Get Access","Obtenir l’Accès"],
  "link_ContactUs":["Contact Us","Contactez-Nous"],
  "langButton":["EN","FR"],
  "showFilters":["Show Filters","Afficher les Filtres"],
  "hideFilters":["Hide Filters","Masquer les Filtres"],
  "clearAllButton":["Clear All","Clear All"],
  "link_Home":['Home', "Page d'Accueil"],
};

function setTitle(id){
  activeTitle = text[id][lang];
  document.getElementById('title-text').innerHTML = activeTitle;
}

function toggleLang(){
  lang = 1-lang;
  var links = document.querySelectorAll(".sidebar a, .topbar a, .topbar button, #filter-panel *");

  Array.prototype.map.call(links, function(e) {
    //console.log('starting for '+e.id);
    if (text[e.id] != undefined){
      e.innerHTML=text[e.id][lang];
    }
  });
  setFilterButtonText();
  let activeLink = $('.active');
  if (activeLink.length > 1){
    alert('error, more than one link active?');
  }
  activeLink = activeLink[0];
  setTitle(activeLink.id);
}

function setFilterButtonText(){
  let open = $('#filter-panel').hasClass('open');
  filterButton.innerHTML = open?text['hideFilters'][lang]:text['showFilters'][lang];
}

function DashLoad(DashName, firstLoad=false){
  const  topbarHeight = 50; // If you change this, remember to change it in the SCSS as well!
  const vizXY = ['100%', window.innerHeight-topbarHeight+'px'];
  const vizOptionsGlobal = {
    width: vizXY[0],
    height: vizXY[1],
    hideTabs: true,
  };
  let vizDiv = document.getElementById("myViz");
  
  let vizOptions = Object.assign({}, vizOptionsGlobal);
  vizOptions = Object.assign(vizOptions, getFilterValues());
  console.log('vizOptions');
  //console.log(vizOptions); 
  for(var pair of Object.entries(vizOptions)) {
    console.log(pair[0]+ ', '+ pair[1]);
  }
  
  let homeUrl = "https://tableaussi-prod.cibcwm.com/t/DelOps/views/BCRMRecapDashboard-FY19/Transit?:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no";

  if (firstLoad){
    vizOptions['Transit']='00001'; // Janky fix for a weird browser cookie issue where if we load without this option, it will be stuck on transit 1.
    // Instead, we explicitly load transit 1, and then remove the option to allow loading all transits.
    // If anyone knows how to fix this in the future, please do
    viz = new tableau.Viz(vizDiv, homeUrl, vizOptions);

    delete(vizOptions['Transit']);
  }

  viz.dispose();

  let DashURL = "";
    
    //switch to change the tableau settings per page
    switch (DashName) {
      case "OICC":
        DashURL = "https://tableaussi-prod.cibcwm.com/t/DelOps/views/OICCFY19/OICCReporting?:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no";
        break;
      case "Home":
        DashURL = homeUrl;
        break;
      case "Fates":
        DashURL = "https://tableaussi-prod.cibcwm.com/t/DelOps/views/FatesFY19/FatesReporting?:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no";
       break;
      
	case "SMNew":
        DashURL = "https://tableaussi-prod.cibcwm.com/t/DelOps/views/Sales_Monitoring_KYB/BCSalesMonitoringReviewOutcomes?iframeSizedToWindow=true&:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no";
	break;

      case "AML":
        DashURL = "https://tableaussi-prod.cibcwm.com/t/DelOps/views/AML_0/Dashboard1?:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no";

        break;
      case "Cash":
        DashURL = "https://tableaussi-prod.cibcwm.com/t/DelOps/views/FY19CashBranch/BranchCashReporting?:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no";

        break;
      case "OpLoss":
          DashURL = "https://tableaussi-prod.cibcwm.com/t/DelOps/views/OpLossMonitoring_201901_Revamped/OperationalLoss?:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no";

        break;
		case "MFDA":
          DashURL = "https://tableaussi-prod.cibcwm.com/t/DelOps/views/MFDAFY19/MFDADashboard?:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no";
		
		// var options = {
          // width: "100%",
          // height: "2200px",
          // hideTabs: true,
        // };
        break;
		case "IIROC":
          DashURL = "https://tableaussi-prod.cibcwm.com/t/DelOps/views/IIROCFY19/IIROCDashboard?:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no";
		
    // var options = {
          // width: "100%",
          // height: "2200px",
          // hideTabs: true,
        // };
        break;
      case "SC":
        DashURL = "https://tableaussi-prod.cibcwm.com/t/DelOps/views/ServiceCommitmentFY19/ServiceCommitmentDashboard?:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no";

        // var options = {
          // width: "100%",
          // height: "2200px",
          // hideTabs: true,
        // };
        break;		
	  case "CR_Summary":
        DashURL = "https://tableaussi-prod.cibcwm.com/t/DelOps/views/CBFE_SC_Simplified_Dashboard/CBFE_SC_Simplified?iframeSizedToWindow=true&:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no";

        // var options = {
          // width: "100%",
          // height: "2200px",
          // hideTabs: true,
        // };
        break;
	  case "CR_TXN":
        DashURL = "https://tableaussi-prod.cibcwm.com/t/DelOps/views/CBFE_SC_Transactions_Dashboard/CBFE_SC_Transactions_Dashboard?iframeSizedToWindow=true&:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no";

        // var options = {
          // width: "100%",
          // height: "2200px",
          // hideTabs: true,
        // };
        break;
      case "LDD":
        DashURL = "https://tableaussi-prod.cibcwm.com/t/DelOps/views/LDDDashboard/LDD-Geography?:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no";

        break;
      case "LDD_RQ":
        DashURL = "https://tableaussi-prod.cibcwm.com/t/DelOps/views/LendingDueDiligenceRandomQueueEscalations/LDDRQDashboard?iframeSizedToWindow=true&:embed=y&:display_count=no&:showAppBanner=false&:showVizHome=no";

        break;
      case "LDD_New":
        DashURL = "https://tableaussi-prod.cibcwm.com/t/DelOps/views/LDDDashboardKYBRevamp/LDDDashboard?iframeSizedToWindow=true&%3Aembed=y&%3AshowAppBanner=false&%3Adisplay_count=no&%3AshowVizHome=no#1";

        break;
	  case "BCSM1":
        DashURL = "https://tableaussi-prod.cibcwm.com/t/DelOps/views/BankingCentres-ConductRiskSalesMonitoringOutcomes/BCSalesMonitoring-ReviewOutcomes?:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no";

        break;
      case "BCSM2":
        DashURL = "https://tableaussi-prod.cibcwm.com/t/DelOps/views/BankingCentres-ConductRiskSalesMonitoringOutcomes/BCSalesMonitoring-FinalEmployeeActions?%3Aembed=y&%3AshowAppBanner=false&%3Adisplay_count=no&%3AshowVizHome=no";

        break;
      case "DTS2":
        DashURL = "https://tableaussi-prod.cibcwm.com/t/DelOps/views/DutyTestingSummary/RDView?:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no";

        break;
      case "DTS1":
        DashURL = "https://tableaussi-prod.cibcwm.com/t/DelOps/views/DutyTestingSummary/RiskView?:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no";

        break;
      case "DTS3":
        DashURL = "https://tableaussi-prod.cibcwm.com/t/DelOps/views/DutyTestingSummary/DutyAdherenceIndicatorDB?:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no";

        break;
      case "CR":
        DashURL = "https://tableaussi-prod.cibcwm.com/t/DelOps/views/DutyTestingCriteriaResults/CriteriaResults?:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no";

        break;
      case "CTI":
        DashURL = "https://tableaussi-prod.cibcwm.com/t/DelOps/views/CentralizedTestingInsights/CTInsights?:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no";

        break;

	case "SA":
        DashURL = "https://teams.cibc.com/sites/ibcs/FRS/Know%20Your%20Branch%20KYB%20Connaitre%20son%20centre%20bancaire/Reports/Suspense%20accounts";

        break;
	case "WhatsNew":
        DashURL = "https://teams.cibc.com/sites/ibcs/FRS/Know%20Your%20Branch%20KYB%20Connaitre%20son%20centre%20bancaire/What's%20New.pdf";

        break;
	case "TimelineSLA":
        DashURL = "https://teams.cibc.com/sites/gtrm/Partner%20Zone/Tableau%20Reporting/KYB/KYB%20Dashboard%20Expected%20Publication%20and%20Owners.pdf";

        break;
      case "UGBCRM":
        DashURL = "https://teams.cibc.com/sites/gtrm/Partner%20Zone/Tableau%20Reporting/KYB/BCRM%20User%20Guide%202019%20(final).pdf";

        // var options = {
          // width: "100%",
          // height: "1000px",
          // hideTabs: true,
        // };
        break;
	  case "UGERPM":
        DashURL = "https://teams.cibc.com/sites/gtrm/Partner%20Zone/Tableau%20Reporting/KYB/ERPM%20User%20Guide%202019%20(final).pdf";

        // var options = {
          // width: "100%",
          // height: "1000px",
          // hideTabs: true,
        // };
        break;
      case "UGMRCB":
        DashURL = "https://teams.cibc.com/sites/gtrm/Partner%20Zone/Tableau%20Reporting/KYB/MRCB%20Guide%20de%20l'utilisateur%202019%20(final).pdf";

        // var options = {
          // width: "100%",
          // height: "1000px",
          // hideTabs: true,
        // };
        break;
	  case "UGMRRE":
        DashURL = "https://teams.cibc.com/sites/gtrm/Partner%20Zone/Tableau%20Reporting/KYB/MRRE%20Guide%20de%20l'utilisateur%202019%20(final).pdf";

        // var options = {
          // width: "100%",
          // height: "1000px",
          // hideTabs: true,
        // };
        break;
      case "KYB":
        DashURL = "https://teams.cibc.com/sites/gtrm/Partner%20Zone/Tableau%20Reporting/KYB/KYB%20Dashboard%20Quick%20Start%20Guide.pdf";

        // var options = {
          // width: "100%",
          // height: "1000px",
          // hideTabs: true,
        // };
        break;
    }
    if(DashURL != ""){
      vizURL = DashURL;
      viz = new tableau.Viz(vizDiv, vizURL, vizOptions);
    }
}



function setInputFilter(textbox, inputFilter, numDigits) {
  ["input", "keydown", "keyup", "mousedown", "mouseup", "select", "contextmenu", "drop"].forEach(function(event) {
    textbox.addEventListener(event, function() {
    if (inputFilter(this.value)) {
      // delete leading zeroes until we hit an issue
      // then delete trailing nums
      while(this.value.length > numDigits){
        if (this.value[0]==0){
          this.value = this.value.slice(1);
        }
        else{
          this.value = this.value.slice(0,-1);
        }
      }
      if(this.value.length < numDigits){
        this.value = this.value.padStart(numDigits, '0');
      }
      this.oldValue = this.value;
      this.oldSelectionStart = this.selectionStart;
      this.oldSelectionEnd = this.selectionEnd;
      
    }
    else if (this.hasOwnProperty("oldValue")) {
        this.value = this.oldValue;
        this.setSelectionRange(this.oldSelectionStart, this.oldSelectionEnd);
    }
    });
  });
}
