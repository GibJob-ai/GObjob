# Architecture
* For whatever reason, we wanted to keep this site as front-end ONLY (ew), so it's just plain js/css
* jquery and the tableau api are imported automatically by downloading from their urls

# SCSS
* SCSS is just nicer CSS syntax. The scss dir contains the stylesheets that you should edit
* Install sass first
* then run:
>scss/scss_compile.sh

* or, if you want it to compile continuously (during development)
>scss/scss_compile.sh --loop

# TODOs
* I had to ditch this project to prioritize KYB Form, so this is unfinished.
* Loading the PDFs from the dropdown is broken for some reason, I haven't really had a chance to look into it
* The burger menu was adopted to make it easier to support mobile, but I didn't actually write the scss to make this display well on mobile yet
