#!/bin/bash

# Compiles SCSS files, run via.
# ./scss_compile.sh
# OR, to run in a continuous loop (for development)
# ./scss_compile.sh --loop

for i in "$@"
do
case $i in
    -loop|--loop)
    LOOP='true'
    shift # past argument=value
    ;;
    *)
          # unknown option
    ;;
esac
done

# Allow running the script from either base dir or scss dir
if [ -d ./scss ] && ! [ -f ./main.scss ]
then
    echo "main.scss not found in ${PWD}, moving to ${PWD}/scss"
    cd scss
fi

if [ ${LOOP} ]
then
    stdbuf -oL sass main.scss ../css/main.css --update --watch |
        while IFS= read -r line
        do
            echo "$line"
        done
else
    echo "Running once"
    OUTPUT="$(sass main.scss ../css/main.css --update)"
    echo "${OUTPUT}"
    echo "built"
fi
